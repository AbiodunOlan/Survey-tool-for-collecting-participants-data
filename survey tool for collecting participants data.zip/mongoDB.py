# Update submit route in app.py
from pymongo import MongoClient

client = MongoClient('mongodb://localhost:27017/')
db = client['survey_db']
collection = db['user_data']

@app.route('/submit', methods=['POST'])
def submit():
    age = request.form['age']
    gender = request.form['gender']
    total_income = request.form['total_income']
    expenses = {
        'utilities': request.form.get('utilities_amount', 0),
        'entertainment': request.form.get('entertainment_amount', 0),
        'school_fees': request.form.get('school_fees_amount', 0),
        'shopping': request.form.get('shopping_amount', 0),
        'healthcare': request.form.get('healthcare_amount', 0),
    }
    user_data = {
        'age': age,
        'gender': gender,
        'total_income': total_income,
        'expenses': expenses
    }
    collection.insert_one(user_data)
    return redirect(url_for('index'))
