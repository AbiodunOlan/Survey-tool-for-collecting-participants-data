# process_data.py
import pandas as pd
from user import User, save_to_csv

# Connect to MongoDB and retrieve data
from pymongo import MongoClient
client = MongoClient('mongodb://localhost:27017/')
db = client['survey_db']
collection = db['user_data']

# Fetch data
data = list(collection.find())

# Transform data
processed_data = []
for entry in data:
    user = User(
        age=entry['age'],
        gender=entry['gender'],
        total_income=entry['total_income'],
        expenses=entry['expenses']
    )
    processed_data.append({
        'age': user.age,
        'gender': user.gender,
        'total_income': user.total_income,
        **user.expenses
    })

save_to_csv(processed_data, 'user_data.csv')
